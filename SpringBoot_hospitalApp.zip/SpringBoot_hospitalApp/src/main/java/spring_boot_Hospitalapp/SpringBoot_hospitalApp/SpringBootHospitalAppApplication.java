package spring_boot_Hospitalapp.SpringBoot_hospitalApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHospitalAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHospitalAppApplication.class, args);
	}

}
