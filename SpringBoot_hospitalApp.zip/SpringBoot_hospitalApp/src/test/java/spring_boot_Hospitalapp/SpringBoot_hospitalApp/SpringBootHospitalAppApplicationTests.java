package spring_boot_Hospitalapp.SpringBoot_hospitalApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHospitalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
